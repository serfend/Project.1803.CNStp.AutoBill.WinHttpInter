﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace JsHelp.API.StampTarget
{
	class Stamp
	{
		private string id;
		private double price;
		private int maxBuyNum;
		private string tmp233;
	}
}
