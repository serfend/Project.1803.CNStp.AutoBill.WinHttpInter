﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace JsHelp.API
{
	class TestMethod
	{
		private User.User user;
		public bool Login()
		{
			user = new User.User();
			user.InputUserByUser();
			return user.Login();
		}
	}
}
