﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;

namespace JsHelp.API.User
{
	class LoginHandle
	{
		public static byte[] GetVerifyImg(User user )
		{
			CookieContainer cookieContainer = new CookieContainer();
			cookieContainer.Add(new Cookie("JSESSIONID", user.JSESSIONID,"/","passport.11185.cn"));   // 加入Cookie
			HttpClientHandler httpClientHandler = new HttpClientHandler()
			{
				CookieContainer = cookieContainer,
				AllowAutoRedirect = true,
				UseCookies = true
			};
			using (var client = new HttpClient(httpClientHandler))
			{
				client.DefaultRequestHeaders.Add("Host", "passport.11185.cn:8001");
				client.DefaultRequestHeaders.Add("Method", "Get");
				client.DefaultRequestHeaders.Add("Referer", "https://passport.11185.cn:8001/cas/tlogin?service=http%3A%2F%2Fjiyou.main.11185.cn%2Fu%2FbuyerCenter.html");
				client.DefaultRequestHeaders.Add("UserAgent", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36");
				var response=client.GetAsync("https://passport.11185.cn:8001/cas/captcha/captcha;jsessionid="+user.JSESSIONID).Result;
				response.EnsureSuccessStatusCode();
				return response.Content.ReadAsByteArrayAsync().Result;

			};
		}
		public static string GetLoginLocation(string lt,string execution,string code,User user)
		{
			CookieContainer cookieContainer = new CookieContainer();
			cookieContainer.Add(new Cookie("JSESSIONID", user.JSESSIONID, "/", "passport.11185.cn"));
			cookieContainer.Add(new Cookie("TGC","" ,"/", "passport.11185.cn"));
			cookieContainer.Add(new Cookie("CASPRIVACY", "", "/", "passport.11185.cn"));
			HttpClientHandler httpClientHandler = new HttpClientHandler()
			{
				CookieContainer = cookieContainer,
				AllowAutoRedirect = true,
				UseCookies = true,
				UseProxy=true,
				Proxy = new WebProxy("127.0.0.1", 8888)
			};
			var encodedPassword = new Password.PasswordEncoder().GetPasswordRAS(user.Password);
			HttpContent postContent = new FormUrlEncodedContent(new Dictionary<string, string>()
		   {
				{"username", user.Username},
				{"password",encodedPassword },
				{"code",code },
				{"lt",lt },
				{"execution",execution},
				{"_eventId","submit"}
		   });
			using (var client = new HttpClient(httpClientHandler))
			{

				client.DefaultRequestHeaders.Add("Host", "passport.11185.cn:8001");
				client.DefaultRequestHeaders.Add("Connection", "keep-alive");
				client.DefaultRequestHeaders.Add("Cache-Control", "max-age=0");
				client.DefaultRequestHeaders.Add("Origin", "https://passport.11185.cn:8001");
				client.DefaultRequestHeaders.Add("Upgrade-Insecure-Requests", "1");
				client.DefaultRequestHeaders.Add("UserAgent", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36");
				//client.DefaultRequestHeaders.Add("Content-Type", "application/x-www-form-urlencoded");
				client.DefaultRequestHeaders.Add("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
				client.DefaultRequestHeaders.Add("Referer", "https://passport.11185.cn:8001/cas/tlogin?service=http%3A%2F%2Fjiyou.main.11185.cn%2Fu%2FbuyerCenter.html");
				client.DefaultRequestHeaders.Add("Accept-Encoding", "gzip, deflate, br");
				client.DefaultRequestHeaders.Add("Accept-Language", "zh-CN,zh;q=0.8");
				client.DefaultRequestHeaders.Add("Expect", "none");
				
				
				
				
				var targetUrl = "https://passport.11185.cn:8001/cas/tlogin?service=http%3A%2F%2Fjiyou.main.11185.cn%2Fu%2FbuyerCenter.html";// string.Format("https://passport.11185.cn:8001/cas/tlogin;JSESSIONID={0}?service=http%3A%2F%2Fjiyou.main.11185.cn%2Fu%2FbuyerCenter.html", user.JSESSIONID);
				var response = client.PostAsync(targetUrl,postContent).Result;
				response.EnsureSuccessStatusCode();
				var resultInfo = response.Content.ReadAsStringAsync().Result;
				if (resultInfo.Contains("用户名或密码错误"))
				{
					user.LoginFailed("用户名或密码错误");
					return null;
				}else if (resultInfo.Contains("验证码错误"))
				{
					user.LoginFailed("验证码错误");
					return null;
				}
				response.Headers.TryGetValues("Location", out IEnumerable<string> values);
				foreach(var value in values)
				{
					if (value.Contains("Location"))
					{
						break;
					}
				}
				return null;
			};
		}
	}
}
