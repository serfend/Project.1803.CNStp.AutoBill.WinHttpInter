﻿using DotNet4.Utilities.UtilCode;
using DotNet4.Utilities.UtilInput;
using DotNet4.Utilities.UtilVerify;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace JsHelp.API.User
{
	class User
	{
		private UtilNormal http=new UtilNormal();
		private RuoKuaiHttp verifier = new RuoKuaiHttp();
		public enum BillStatus
		{
			NotLogin,Login,BeenPay
		}
		private string _JSESSIONID;

		private string username;
		private string password;
		private TimeSpan lastUse;
		private BillStatus status;

		/// <summary>
		/// 手动输入
		/// </summary>
		public User()
		{

		}
		public User(string username, string password)
		{
			this.username = username;
			this.password = password;
		}

		public string Username { get => username; set => username = value; }
		public string Password { get => password; set => password = value; }
		public TimeSpan LastUse { get => lastUse;private set => lastUse = value; }
		internal BillStatus Status { get => status;private set => status = value; }
		public string JSESSIONID { get => _JSESSIONID;private set => _JSESSIONID = value; }
		public void InputUserByUser()
		{
			this.username = InputBox.ShowInputBox("用户建立", "用户名", "3DzvNdRbrj");
			this.password = InputBox.ShowInputBox("用户建立", "密码", "shileizuim");
		}
		public bool Login()
		{
			JSESSIONID = http.JSESSIONID(out string lt,out string execution,out string actionUrl);
			if (JSESSIONID == null) return false;
			var verifyImg = LoginHandle.GetVerifyImg(this);
			var verifyResult = verifier.GetVer(RuoKuaiHttp.ver3040Config, verifyImg);
			var loginLocation = LoginHandle.GetLoginLocation(lt, execution, verifyResult,this);
			return true;
		}

		internal void LoginFailed(string reason)
		{
			Console.WriteLine(this.ToString() +"登录失败：" + reason);
		}
		public override string ToString()
		{
			return this.Username + "(" + this.Password + ")";
		}
	}
	class UserInfomation
	{
		private string JSESSIONID;//用于标识用户
		private string phone;

		public string Phone { get => phone;
			set {
				//TODO 用户登录状态时可通过用户信息页修改
			}
		}
	}
}
