﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Net.Http;
using System.Drawing;
using System.Threading.Tasks;
using DotNet4.Utilities.UtilCode;
using JsHelp.API.User;

namespace JsHelp.API
{
	class UtilNormal
	{
		HttpClient http;
		public UtilNormal()
		{
			http = new HttpClient();
		}

		public string JSESSIONID(out string lt, out string excution, out string actionUrl)
		{
			var responseInfo = http.GetAsync("http://jiyou.main.11185.cn/u/buyerCenter.html").Result;
			var responseHeaders = responseInfo.Headers;
			var responseContent = responseInfo.Content.ReadAsStringAsync().Result;
			actionUrl = "https://passport.11185.cn:8001" + HttpUtil.GetElement(responseContent, "action=\"", "\"");
			responseHeaders.TryGetValues("Set-Cookie", out IEnumerable<string> values);
			lt = HttpUtil.GetElement(responseContent, "name=\"lt\" value=\"","\"");
			excution = HttpUtil.GetElement(responseContent, "name=\"execution\" value=\"", "\"");
			string tmpJSessionId = null ;
			foreach(var value in values)
			{
				if (value.Contains("JSESSIONID="))
				{
					tmpJSessionId = HttpUtil.GetElement(value, "=", ";");
					break;
				}
			}
			return tmpJSessionId;
		}

		public string Send(string url)
		{
			//TODO GetHtml
			return null;
		}

	}
}